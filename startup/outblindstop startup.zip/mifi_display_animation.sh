#!/bin/sh
#
# splash_animation
#

export PATH=$PATH:/opt/nvtl/bin
export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/opt/nvtl/lib

BASE_PATH=/opt/nvtl/data/branding/startup/animation_
NUM_FILES=389
USLEEP=17995

cache_files()
{
    COUNT=1
    while [ $COUNT -lt $NUM_FILES ]; do
        dd if=$BASE_PATH$COUNT.png of=/dev/null bs=32K > /dev/null 2>&1
        let COUNT=COUNT+1
    done
}

case $1 in
    start)
        echo "power on animation cache files started" > /dev/kmsg
        cache_files
        echo "[MIFI_TIMESTAMP] - power on animation started" > /dev/kmsg
        chrt -f 1 /opt/nvtl/bin/mifi_display_png $BASE_PATH $NUM_FILES $USLEEP &
        ;;
    stop)
        echo "stopping splashscreen animation"
        killall -q mifi_display_png
        ;;
esac
